import { useState } from "react";
import { useNavigate, Link } from "react-router";
import { motion } from "motion/react";
import { Briefcase, Mail, Lock, Eye, EyeOff, User, Phone, Briefcase as BriefcaseIcon, UserCheck } from "lucide-react";

type AccountType = "JOBSEEKER" | "RECRUITER";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } },
};

export default function RegisterPage() {
  const navigate = useNavigate();
  const [accountType, setAccountType] = useState<AccountType>("JOBSEEKER");
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", password: "", confirmPassword: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const update = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [field]: e.target.value });

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (form.password !== form.confirmPassword) { setError("Passwords do not match."); return; }
    if (form.password.length < 6) { setError("Password must be at least 6 characters."); return; }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    navigate(accountType === "RECRUITER" ? "/recruiter/home" : "/home");
    setLoading(false);
  };

  const isRecruiter = accountType === "RECRUITER";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-950 dark:via-blue-950 dark:to-indigo-950 flex items-center justify-center p-4 py-10 relative overflow-hidden">
      {/* blobs */}
      <motion.div
        className="absolute top-10 right-10 w-80 h-80 bg-blue-200/40 dark:bg-blue-900/20 rounded-full blur-3xl pointer-events-none"
        animate={{ scale: [1, 1.12, 1], opacity: [0.35, 0.55, 0.35] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-10 left-10 w-64 h-64 bg-violet-200/40 dark:bg-violet-900/20 rounded-full blur-3xl pointer-events-none"
        animate={{ scale: [1.1, 1, 1.1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className="w-full max-w-md relative"
        initial={{ opacity: 0, y: 36 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="bg-card border border-border rounded-3xl shadow-xl p-8">
          {/* Header */}
          <motion.div
            className="text-center mb-8"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.4 }}
          >
            <Link to="/" className="inline-flex items-center gap-2 mb-6">
              <motion.div
                className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center"
                whileHover={{ rotate: 10, scale: 1.1 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <Briefcase className="w-5 h-5 text-white" />
              </motion.div>
              <span className="text-2xl font-extrabold text-blue-600" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>JobPortal</span>
            </Link>
            <h1 className="text-2xl font-extrabold text-foreground mb-1" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>Create an account</h1>
            <p className="text-muted-foreground text-sm">Join thousands of professionals today</p>
          </motion.div>

          {/* Account type toggle */}
          <motion.div
            className="mb-6"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.18, duration: 0.4 }}
          >
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">I am a...</p>
            <div className="grid grid-cols-2 gap-3">
              {([
                { type: "JOBSEEKER" as const, icon: UserCheck, label: "Job Seeker", sub: "Looking for work", active: "border-blue-600 bg-blue-50 dark:bg-blue-900/20", activeText: "text-blue-600" },
                { type: "RECRUITER" as const, icon: BriefcaseIcon, label: "Recruiter", sub: "Hiring talent", active: "border-violet-600 bg-violet-50 dark:bg-violet-900/20", activeText: "text-violet-600" },
              ]).map((opt) => (
                <motion.button
                  key={opt.type}
                  type="button"
                  onClick={() => setAccountType(opt.type)}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${
                    accountType === opt.type ? opt.active : "border-border bg-muted/30 hover:border-border/80"
                  }`}
                >
                  <opt.icon className={`w-6 h-6 ${accountType === opt.type ? opt.activeText : "text-muted-foreground"}`} />
                  <span className={`text-sm font-bold ${accountType === opt.type ? opt.activeText : "text-muted-foreground"}`}>{opt.label}</span>
                  <span className="text-xs text-muted-foreground text-center">{opt.sub}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>

          <motion.form
            onSubmit={handleRegister}
            className="space-y-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.28, duration: 0.4 }}
          >
            {error && (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-3 text-sm text-red-700 dark:text-red-400"
              >
                {error}
              </motion.div>
            )}

            {[
              { label: "Full Name", field: "fullName", type: "text", placeholder: "John Doe", icon: User },
              { label: "Email Address", field: "email", type: "email", placeholder: "you@example.com", icon: Mail },
              { label: "Phone Number", field: "phone", type: "tel", placeholder: "+84 90 1234 567", icon: Phone },
            ].map((f) => (
              <div key={f.field}>
                <label className="text-sm font-semibold text-foreground mb-1.5 block">{f.label}</label>
                <div className="relative">
                  <f.icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type={f.type}
                    value={form[f.field as keyof typeof form]}
                    onChange={update(f.field)}
                    placeholder={f.placeholder}
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-input-background border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-all text-sm"
                  />
                </div>
              </div>
            ))}

            {[
              { label: "Password", field: "password", show: showPassword, toggle: () => setShowPassword(!showPassword), placeholder: "Min. 6 characters" },
              { label: "Confirm Password", field: "confirmPassword", show: showConfirm, toggle: () => setShowConfirm(!showConfirm), placeholder: "Re-enter password" },
            ].map((f) => (
              <div key={f.field}>
                <label className="text-sm font-semibold text-foreground mb-1.5 block">{f.label}</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type={f.show ? "text" : "password"}
                    value={form[f.field as keyof typeof form]}
                    onChange={update(f.field)}
                    placeholder={f.placeholder}
                    required
                    className="w-full pl-10 pr-10 py-2.5 bg-input-background border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary transition-all text-sm"
                  />
                  <button type="button" onClick={f.toggle} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {f.show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            ))}

            <p className="text-xs text-muted-foreground">
              By registering, you agree to our{" "}
              <button type="button" className="text-blue-600 hover:underline">Terms of Service</button> and{" "}
              <button type="button" className="text-blue-600 hover:underline">Privacy Policy</button>.
            </p>

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`w-full py-3 text-white font-bold rounded-xl transition-colors shadow-md disabled:opacity-60 ${
                isRecruiter
                  ? "bg-violet-600 hover:bg-violet-700 shadow-violet-600/20"
                  : "bg-blue-600 hover:bg-blue-700 shadow-blue-600/20"
              }`}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <motion.span
                    className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full inline-block"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                  />
                  Creating account...
                </span>
              ) : `Create ${isRecruiter ? "Recruiter" : "Job Seeker"} Account`}
            </motion.button>
          </motion.form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have an account?{" "}
            <Link to="/login" className="text-blue-600 font-semibold hover:text-blue-700">Sign in</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
